package com.frc.backend.dao;

import com.frc.backend.modelo.Designer;

public class DesignerDAO extends GenericDAO<Designer> {
    public DesignerDAO() {
        super(Designer.class);
    }
}
