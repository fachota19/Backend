package com.frc.backend;

import com.frc.backend.infra.DbInitializer;
import com.frc.backend.infra.LocalEntityManagerProvider;

import javax.persistence.EntityManager;

/**
 * Clase principal del pre-enunciado.
 * Ejecuta la inicialización del DDL y prueba el mapeo JPA/Hibernate.
 */
public class App {

    public static void main(String[] args) {

        System.out.println("=== BOARD GAMES - VALIDACIÓN DE ENTORNO ===");

        // 1. Ejecutar script SQL para crear las tablas
        DbInitializer.init();

        // 2. Crear un EntityManager y probar el mapeo JPA
        try {
            EntityManager em = LocalEntityManagerProvider.getFactory().createEntityManager();

            // Prueba de mapeo: contar registros (debería dar 0 si no hay seed)
            Long count = (Long) em.createQuery("SELECT COUNT(c) FROM Category c").getSingleResult();
            System.out.println("[OK] DB init + JPA mappings verificados. Registros en CATEGORIES: " + count);

            em.close();
        } catch (Exception e) {
            System.err.println("[FAIL] Error en validación de JPA: " + e.getMessage());
            e.printStackTrace();
        }

        System.out.println("=== FIN DE VALIDACIÓN ===");
    }
}
