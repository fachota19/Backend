package com.frc.backend.dao;

import com.frc.backend.modelo.Category;

public class CategoryDAO extends GenericDAO<Category> {
    public CategoryDAO() {
        super(Category.class);
    }
}
