package com.frc.backend.dao;

import com.frc.backend.modelo.Publisher;

public class PublisherDAO extends GenericDAO<Publisher> {
    public PublisherDAO() {
        super(Publisher.class);
    }
}
