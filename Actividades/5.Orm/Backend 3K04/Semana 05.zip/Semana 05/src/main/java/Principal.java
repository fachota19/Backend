import entidades.Alumno;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.io.InputStream;
import java.util.Scanner;

public class Principal {

    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence
                .createEntityManagerFactory("MiUnidad");
        EntityManager em = emf.createEntityManager();


        em.getTransaction().begin();

        Alumno a = new Alumno();
        a.setNombre("Pepe");
        em.persist(a);

        a.setNombre("Pepe Argento");
        em.persist(a);

        em.getTransaction().commit();

//        Alumno alumno = em.find(Alumno.class, 2);
//        em.getTransaction().begin();
//        em.remove(alumno);
//        em.getTransaction().commit();
//        System.out.println(alumno);

        em.close();


        InputStream resourceAsStream = Principal.class.getResourceAsStream("/pasajes.csv");
        Scanner sc = new Scanner(resourceAsStream);
        while(sc.hasNext()) {
            System.out.println(sc.nextLine());
        }
    }
}
