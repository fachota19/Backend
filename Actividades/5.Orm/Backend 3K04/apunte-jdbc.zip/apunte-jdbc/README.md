
# Diagrama Entity-Relationship

![img.png](images/er.png)