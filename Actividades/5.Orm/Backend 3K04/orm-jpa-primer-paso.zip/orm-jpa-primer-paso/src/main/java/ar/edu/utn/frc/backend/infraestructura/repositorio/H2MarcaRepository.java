package ar.edu.utn.frc.backend.infraestructura.repositorio;

import ar.edu.utn.frc.backend.dominio.modelo.Marca;
import ar.edu.utn.frc.backend.dominio.repositorio.MarcaRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

import java.util.List;
import java.util.Optional;

public class H2MarcaRepository implements MarcaRepository {
    @Override
    public List<Marca> getAll() {

        try(EntityManagerFactory emf = Persistence
                .createEntityManagerFactory("AutosDB");
            EntityManager em = emf.createEntityManager()){

            Query query = em.createQuery("from Marca m", Marca.class);

            List<Marca> marcas = (List<Marca>) query.getResultList();

            return marcas;

        }
    }

    @Override
    public Optional<Marca> get(Integer id) {
        return Optional.empty();
    }

    @Override
    public Marca save(Marca marca) {
        return null;
    }

    @Override
    public void delete(Marca marca) {

    }
}
