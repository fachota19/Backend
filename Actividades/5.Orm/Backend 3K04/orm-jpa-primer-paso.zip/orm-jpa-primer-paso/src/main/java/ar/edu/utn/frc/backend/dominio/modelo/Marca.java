package ar.edu.utn.frc.backend.dominio.modelo;

import jakarta.persistence.*;

import java.util.Objects;

@Entity
@Table(name = "marca", schema = "backend")
public class Marca {
	@Id
	@Column(name = "ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@Column(name = "NOMBRE", nullable = false, length = 255)
	private String nombre;

	public Marca() {

	}

	public Marca(Integer aId, String aNombre) {
		id = aId;
		nombre = aNombre;
	}

	public Marca(String aNombre) {
		this(null, aNombre);
	}

	public Integer getId() {
		return id;
	}

	public String getNombre() {
		return nombre;
	}

	@Override public String toString() {
		return "Marca{" +
			"nombre='" + nombre + '\'' +
			'}';
	}

	@Override public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		Marca marca = (Marca) o;
		return Objects.equals(id, marca.id);
	}

	@Override public int hashCode() {
		return Objects.hash(id);
	}
}
