## Datos
* DB URL `jdbc:h2:file:./.h2/testdb`
* Dialect `org.hibernate.dialect.H2Dialect`
* Driver `org.h2.Driver`

## Diagrama Entity-Relationship

![img.png](images/er.png)