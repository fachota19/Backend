package com.frc.isi.museo.menu;

public record ItemMenu(int indice, String mesaje, OpcionMenu accion) {

}
