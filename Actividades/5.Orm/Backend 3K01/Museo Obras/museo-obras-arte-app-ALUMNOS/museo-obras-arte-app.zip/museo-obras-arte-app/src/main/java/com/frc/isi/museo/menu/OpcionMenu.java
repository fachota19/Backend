package com.frc.isi.museo.menu;

@FunctionalInterface
public interface OpcionMenu {
    void invocar(ApplicationContext ctx);
}
