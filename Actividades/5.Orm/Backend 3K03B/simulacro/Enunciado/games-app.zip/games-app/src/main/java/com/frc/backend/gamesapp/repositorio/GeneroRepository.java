package com.frc.backend.gamesapp.repositorio;

import com.frc.backend.gamesapp.modelo.Genero;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.util.List;

public class GeneroRepository {
    private final EntityManager em;

    public GeneroRepository(EntityManager em) {
        this.em = em;
    }

    public Genero guardarSiNoExiste(String nombre) {
        TypedQuery<Genero> q = em.createQuery("FROM Genero g WHERE g.nombre = :nombre", Genero.class);
        q.setParameter("nombre", nombre);
        List<Genero> existentes = q.getResultList();
        if (!existentes.isEmpty()) return existentes.get(0);

        em.getTransaction().begin();
        Genero nuevo = new Genero(null, nombre);
        em.persist(nuevo);
        em.getTransaction().commit();
        return nuevo;
    }
}
