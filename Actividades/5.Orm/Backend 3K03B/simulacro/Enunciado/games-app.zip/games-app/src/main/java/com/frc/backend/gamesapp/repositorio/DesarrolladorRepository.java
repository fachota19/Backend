package com.frc.backend.gamesapp.repositorio;

import com.frc.backend.gamesapp.modelo.Desarrollador;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.util.List;

public class DesarrolladorRepository {
    private final EntityManager em;

    public DesarrolladorRepository(EntityManager em) {
        this.em = em;
    }

    public Desarrollador guardarSiNoExiste(String nombre) {
        TypedQuery<Desarrollador> q = em.createQuery("FROM Desarrollador d WHERE d.nombre = :nombre", Desarrollador.class);
        q.setParameter("nombre", nombre);
        List<Desarrollador> existentes = q.getResultList();
        if (!existentes.isEmpty()) return existentes.get(0);

        em.getTransaction().begin();
        Desarrollador nuevo = new Desarrollador(null, nombre);
        em.persist(nuevo);
        em.getTransaction().commit();
        return nuevo;
    }
}
