package com.frc.backend.gamesapp.repositorio;

import com.frc.backend.gamesapp.modelo.Juego;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.util.List;

public class JuegoRepository {
    private final EntityManager em;

    public JuegoRepository(EntityManager em) {
        this.em = em;
    }

    public void guardar(Juego juego) {
        em.getTransaction().begin();
        em.persist(juego);
        em.getTransaction().commit();
    }

    public List<Juego> listarTodos() {
        TypedQuery<Juego> q = em.createQuery("FROM Juego", Juego.class);
        return q.getResultList();
    }
}
