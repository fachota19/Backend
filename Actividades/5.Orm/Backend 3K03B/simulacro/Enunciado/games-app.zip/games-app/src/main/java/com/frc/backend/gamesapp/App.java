package com.frc.backend.gamesapp;

import com.frc.backend.gamesapp.modelo.*;
import com.frc.backend.gamesapp.repositorio.*;
import com.opencsv.CSVReader;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.io.InputStreamReader;
import java.util.List;

public class App {

    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("gamesPU");
        EntityManager em = emf.createEntityManager();

        inicializarBase(em);

        GeneroRepository generoRepo = new GeneroRepository(em);
        PlataformaRepository platRepo = new PlataformaRepository(em);
        DesarrolladorRepository desaRepo = new DesarrolladorRepository(em);
        JuegoRepository juegoRepo = new JuegoRepository(em);

        try (CSVReader reader = new CSVReader(new InputStreamReader(
                App.class.getClassLoader().getResourceAsStream("games_data.csv")))) {

            reader.skip(1); // saltar encabezado
            String[] linea;
            while ((linea = reader.readNext()) != null) {
                String titulo = linea[0];
                int anio = Integer.parseInt(linea[1]);
                String genero = linea[2];
                String plataforma = linea[3];
                String desarrollador = linea[4];
                String esrb = linea[5];
                double rating = Double.parseDouble(linea[6]);
                int finalizados = Integer.parseInt(linea[7]);
                int jugando = Integer.parseInt(linea[8]);
                String resumen = linea[9];

                Genero g = generoRepo.guardarSiNoExiste(genero);
                Plataforma p = platRepo.guardarSiNoExiste(plataforma);
                Desarrollador d = desaRepo.guardarSiNoExiste(desarrollador);

                Juego juego = Juego.builder()
                        .titulo(titulo)
                        .fechaLanzamiento(anio)
                        .genero(g)
                        .plataforma(p)
                        .desarrollador(d)
                        .clasificacionESRB(esrb)
                        .rating(rating)
                        .juegosFinalizados(finalizados)
                        .jugando(jugando)
                        .resumen(resumen)
                        .build();

                juegoRepo.guardar(juego);
            }

            System.out.println("✅ Juegos cargados correctamente");
            List<Juego> juegos = juegoRepo.listarTodos();
            juegos.forEach(j -> System.out.println("🎮 " + j.getTitulo() + " (" + j.getGenero().getNombre() + ")"));

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            em.close();
            emf.close();
        }
    }

    private static void inicializarBase(EntityManager em) {
        try {
            em.getTransaction().begin();
            em.createNativeQuery("SELECT 1").getSingleResult();
            em.getTransaction().commit();
            System.out.println("✅ Base de datos inicializada correctamente (DDL ejecutado).");
        } catch (Exception e) {
            System.err.println("⚠️ Error inicializando base: " + e.getMessage());
        }
    }
}