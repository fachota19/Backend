package com.frc.backend.gamesapp.repositorio;

import com.frc.backend.gamesapp.modelo.Plataforma;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import java.util.List;

public class PlataformaRepository {
    private final EntityManager em;

    public PlataformaRepository(EntityManager em) {
        this.em = em;
    }

    public Plataforma guardarSiNoExiste(String nombre) {
        TypedQuery<Plataforma> q = em.createQuery("FROM Plataforma p WHERE p.nombre = :nombre", Plataforma.class);
        q.setParameter("nombre", nombre);
        List<Plataforma> existentes = q.getResultList();
        if (!existentes.isEmpty()) return existentes.get(0);

        em.getTransaction().begin();
        Plataforma nuevo = new Plataforma(null, nombre);
        em.persist(nuevo);
        em.getTransaction().commit();
        return nuevo;
    }
}
