package ar.edu.utn.frc.backend;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.File;
import java.io.FileNotFoundException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import org.junit.jupiter.api.Test;

import ar.edu.utn.frc.backend.modelo.Auto;

public class CollectionTest {

	@Test
	public void devuelveLaCantidadCorrecta() throws FileNotFoundException {

		List<Auto> autos = cargarListaDeAuto();

		int resultado = Collection.obtenerCantidadPorMarcaYAnio(autos, "Audi", 2020);

		assertEquals(7, resultado);
	}

	@Test
	public void devuelveLaCantidadCorrecta2() throws FileNotFoundException {

		List<Auto> autos = cargarListaDeAuto();

		int resultado = Collection.obtenerCantidadPorMarcaYAnio(autos, "BMW", 2021);

		assertEquals(17, resultado);
	}

	@Test
	public void devuelveLaCantidadDeConvertibles() throws FileNotFoundException {

		List<Auto> autos = cargarListaDeAuto();

		int resultado = Collection.obtenerCantidadDeConvertibles(autos);

		assertEquals(14, resultado);
	}

	@Test
	public void devuelveLaCantidadMarcasQueVendanSedanes() throws FileNotFoundException {

		List<Auto> autos = cargarListaDeAuto();

		Set<String> resultado = Collection.obtenerLasMarcasQueVendanSedanes(autos);

		assertArrayEquals(new String[] { "Acura", "Audi", "Alfa Romeo", "BMW", "Bentley" }, resultado.toArray());
	}

	@Test
	public void devuelveLaCantidadCorrectaDeAudi() throws FileNotFoundException {

		List<Auto> autos = cargarListaDeAuto();

		Map<String, Integer> resultado = Collection.obtenerCantidadDeAutosPorMarca(autos);

		assertEquals(31, resultado.get("Audi"));
	}

	@Test
	public void devuelveLaCantidadCorrectaDeFerrari() throws FileNotFoundException {

		List<Auto> autos = cargarListaDeAuto();

		Map<String, Integer> resultado = Collection.obtenerCantidadDeAutosPorMarca(autos);

		assertEquals(3, resultado.get("Ferrari"));
	}

	@Test
	public void devuelveLaCantidadCorrectaDeAutosPorAnio() throws FileNotFoundException {

		List<Auto> autos = cargarListaDeAuto();

		Map<Integer, Integer> resultado = Collection.obtenerCantidadDeAutosPorAnio(autos);

		assertEquals(20, resultado.get(2019));
	}

	private List<Auto> cargarListaDeAuto() throws FileNotFoundException {
		List<Auto> autos = new LinkedList<>();

		return autos;
	}

}
